using AcxiomCRM.Data;
using AcxiomCRM.Models;
using System.Security.Claims;
using System.Text.Json;
namespace AcxiomCRM.Services;
public class AuditService: IAuditService {
    readonly AppDbContext db;
    readonly IHttpContextAccessor http;
    public AuditService(AppDbContext db, IHttpContextAccessor http) {
        this.db = db;
        this.http = http;
    }
    public async Task LogAsync(string action, string entity, string? id, string? oldValue, string? newValue, string result = "Success") {
        db.AuditLogs.Add(new AuditLog {
            UserId = http.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier), Action = action, EntityName = entity, RecordId = id, OldValue = oldValue, NewValue = newValue, CreatedDate = DateTime.UtcNow, IpAddress = http.HttpContext?.Connection.RemoteIpAddress?.ToString(), Result = result
        });
        await db.SaveChangesAsync();
    }
    public static string Snapshot <T>(T x) => JsonSerializer.Serialize(x);
}
