using AcxiomCRM.Data;
using AcxiomCRM.ViewModels;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Services;
public class DashboardService: IDashboardService {
    readonly AppDbContext db;
    public DashboardService(AppDbContext db) => this.db = db;
    public async Task<DashboardViewModel> GetAsync(string userId, bool fullScope) {
        var c = db.Customers.AsNoTracking();
        var l = db.Leads.AsNoTracking();
        var o = db.Opportunities.AsNoTracking();
        var f = db.FollowUps.AsNoTracking();
        if (!fullScope) {
            c = c.Where(x => x.CreatedBy == userId);
            l = l.Where(x => x.AssignedTo == userId);
            o = o.Where(x => x.AssignedTo == userId);
            f = f.Where(x => x.AssignedTo == userId);
        }
        var m = new DashboardViewModel {
            TotalCustomers = await c.CountAsync(), TotalLeads = await l.CountAsync(), OpenLeads = await l.CountAsync(x => x.Status != "Lost" && x.Status != "Converted" && x.Status != "Unqualified"), TotalOpportunities = await o.CountAsync(), OpenOpportunities = await o.CountAsync(x => x.Status == "Open"), WonOpportunities = await o.CountAsync(x => x.Status == "Won"), LostOpportunities = await o.CountAsync(x => x.Status == "Lost"), PendingFollowUps = await f.CountAsync(x => x.Status == "Planned"), OverdueFollowUps = await f.CountAsync(x => x.Status == "Planned" && x.FollowUpDate.Date <DateTime.Today), TotalPipelineValue = await o.Where(x => x.Status == "Open").SumAsync(x => (decimal?) x.Amount) ? ? 0
        };
        m.LeadStatus = await l.GroupBy(x => x.Status).Select(g => new ChartItem(g.Key, g.Count())).ToListAsync();
        m.StageStatus = await o.GroupBy(x => x.Stage).Select(g => new ChartItem(g.Key, g.Count())).ToListAsync();
        m.MonthlySales = await o.Where(x => x.Status == "Won").GroupBy(x => new {
            x.CreatedDate.Year, x.CreatedDate.Month
        }).OrderBy(g => g.Key.Year).ThenBy(g => g.Key.Month).Select(g => new ChartItem($"{g.Key.Year}-{g.Key.Month:00}", (double) g.Sum(x => x.Amount))).ToListAsync();
        return m;
    }
}
