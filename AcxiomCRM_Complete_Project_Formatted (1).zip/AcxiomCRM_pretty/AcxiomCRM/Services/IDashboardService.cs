using AcxiomCRM.ViewModels;
namespace AcxiomCRM.Services;
public interface IDashboardService {
    Task<DashboardViewModel> GetAsync(string userId, bool fullScope);
}
