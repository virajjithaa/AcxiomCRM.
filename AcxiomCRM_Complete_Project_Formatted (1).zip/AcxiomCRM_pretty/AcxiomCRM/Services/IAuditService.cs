namespace AcxiomCRM.Services;
public interface IAuditService {
    Task LogAsync(string action, string entity, string? id, string? oldValue, string? newValue, string result = "Success");
}
