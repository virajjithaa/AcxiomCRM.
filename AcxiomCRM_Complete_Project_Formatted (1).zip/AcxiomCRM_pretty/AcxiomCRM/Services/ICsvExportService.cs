namespace AcxiomCRM.Services;
public interface ICsvExportService {
    byte[] Create <T>(IEnumerable<T> rows);
}
