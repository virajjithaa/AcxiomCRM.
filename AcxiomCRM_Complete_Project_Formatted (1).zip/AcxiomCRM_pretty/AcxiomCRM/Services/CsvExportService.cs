using System.Reflection;
using System.Text;
namespace AcxiomCRM.Services;
public class CsvExportService: ICsvExportService {
    public byte[] Create <T>(IEnumerable<T> rows) {
        var p = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
        var s = new StringBuilder();
        s.AppendLine(string.Join(',', p.Select(x => Esc(x.Name))));
        foreach (var r in rows) s.AppendLine(string.Join(',', p.Select(x => Esc(x.GetValue(r)?.ToString() ? ? ""))));
        return Encoding.UTF8.GetBytes(s.ToString());
    }
    static string Esc(string x) => $"\" {
        x.Replace("\"", "\"\"")
    }
    \ "";
}
