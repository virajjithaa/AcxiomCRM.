using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class FollowUp: IValidatableObject {
    public int FollowUpId {
        get;
        set;
    }
    public int? CustomerId {
        get;
        set;
    }
    public int? LeadId {
        get;
        set;
    }
    public DateTime FollowUpDate {
        get;
        set;
    }
    = DateTime.Today.AddDays(1);
    [Required]
    public string FollowUpType {
        get;
        set;
    }
    = "Call";
    public string? Remarks {
        get;
        set;
    }
    public string Status {
        get;
        set;
    }
    = "Planned";
    public string AssignedTo {
        get;
        set;
    }
    = "";
    public IEnumerable<ValidationResult> Validate(ValidationContext c) {
        if (Status == "Planned" && FollowUpDate.Date <DateTime.Today) yield return new("Follow-up date cannot be earlier than today.", [nameof(FollowUpDate)]);
        if (CustomerId is null && LeadId is null) yield return new("Select a related Customer or Lead.", [nameof(CustomerId), nameof(LeadId)]);
    }
}
