using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class Opportunity: IValidatableObject {
    public int OpportunityId {
        get;
        set;
    }
    [Required, StringLength(160)]
    public string OpportunityName {
        get;
        set;
    }
    = "";
    public int CustomerId {
        get;
        set;
    }
    public int? LeadId {
        get;
        set;
    }
    [Range(typeof(decimal), "0.01", "1000000000000", ErrorMessage = "Opportunity Amount must be greater than 0.")]
    public decimal Amount {
        get;
        set;
    }
    [Required]
    public string Stage {
        get;
        set;
    }
    = "Qualification";
    [Range(0, 100, ErrorMessage = "Probability must be between 0 and 100.")]
    public int Probability {
        get;
        set;
    }
    = 20;
    public DateTime ExpectedCloseDate {
        get;
        set;
    }
    = DateTime.Today.AddDays(30);
    public string Status {
        get;
        set;
    }
    = "Open";
    public DateTime CreatedDate {
        get;
        set;
    }
    = DateTime.UtcNow;
    public string AssignedTo {
        get;
        set;
    }
    = "";
    [StringLength(1000)]
    public string? Notes {
        get;
        set;
    }
    public decimal WeightedPipeline => Amount * Probability / 100m;
    public IEnumerable<ValidationResult> Validate(ValidationContext c) {
        if (Status.Equals("Open", StringComparison.OrdinalIgnoreCase) && ExpectedCloseDate.Date <DateTime.Today) yield return new("Expected Close Date cannot be in the past.", [nameof(ExpectedCloseDate)]);
        if (Amount <= 0) yield return new("Opportunity Amount must be greater than 0.", [nameof(Amount)]);
        if (Probability <0 || Probability> 100) yield return new("Probability must be between 0 and 100.", [nameof(Probability)]);
    }
}
