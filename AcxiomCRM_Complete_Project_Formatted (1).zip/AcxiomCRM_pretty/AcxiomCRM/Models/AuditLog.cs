using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class AuditLog {
    public long AuditLogId {
        get;
        set;
    }
    public string? UserId {
        get;
        set;
    }
    [Required]
    public string Action {
        get;
        set;
    }
    = "";
    [Required]
    public string EntityName {
        get;
        set;
    }
    = "";
    public string? RecordId {
        get;
        set;
    }
    public string? OldValue {
        get;
        set;
    }
    public string? NewValue {
        get;
        set;
    }
    public DateTime CreatedDate {
        get;
        set;
    }
    = DateTime.UtcNow;
    public string? IpAddress {
        get;
        set;
    }
    public string? Result {
        get;
        set;
    }
    = "Success";
}
