using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.Models;
public class ApplicationUser: IdentityUser {
    [Required, StringLength(120)]
    public string DisplayName {
        get;
        set;
    }
    = "";
    public bool IsActive {
        get;
        set;
    }
    = true;
    public DateTime CreatedDate {
        get;
        set;
    }
    = DateTime.UtcNow;
}
