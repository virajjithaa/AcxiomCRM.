# AcxiomCRM Complete Project

This project implements the supplied AcxiomCRM Functional & Technical Project Documentation as an ASP.NET Core MVC application. The source specification calls for a layered CRM, Admin/Manager/SalesExecutive roles, client/server/business validation, secure authentication, lockout, audit logging, REST APIs, dashboard KPIs/Chart.js, search/filtering/pagination and reporting.

## Stack
ASP.NET Core MVC / .NET 8, ASP.NET Core Identity, Entity Framework Core with SQLite, Bootstrap 5 and Chart.js.

## Modules
Authentication & Authorization, Dashboard, Customer Management, Lead Management, Opportunity Management, Follow-Up Management, Activity Management, User & Role Management, Audit Log, REST API and Reports.

## Run
Install the .NET 8 SDK, open this folder, run `dotnet restore`, then `dotnet run`. The database `acxiomcrm.db` is created automatically on first start.

Demo credentials:
- Admin: `admin@acxiomcrm.local` / `Admin@12345`
- Manager: `manager@acxiomcrm.local` / `Manager@12345`
- Sales Executive: `sales@acxiomcrm.local` / `Sales@12345`

Change demo passwords for any real deployment.

## Security
ASP.NET Core Identity handles password hashing, role membership, cookie authentication and lockout. Password policy is 8+ characters with digit/lowercase/uppercase/special character. Failed logins lock an account after 5 attempts for 15 minutes. MVC POST forms use anti-forgery protection. Protected MVC/API resources use server-side authorization. APIs return DTOs rather than EF entities and do not return password/security fields. EF Core LINQ is used for data access.

## Validation
Customer name/email/phone required; email and phone are unique. Lead status is limited to the configured workflow. Opportunity amount must be > 0, probability 0–100, and an active opportunity cannot have a past expected close date. A planned follow-up cannot be dated before today. Client-side unobtrusive validation and server-side validation are both enabled.

## REST APIs
- POST `/api/auth/login`
- POST `/api/auth/logout`
- GET/POST `/api/customers`
- GET/PUT/DELETE `/api/customers/{id}`
- GET/POST `/api/leads`
- GET/POST `/api/opportunities`

## Reports
Customer, Lead, Follow-Up, Opportunity, Pipeline, Conversion, User Activity and Audit reports. Customer/Lead/Opportunity CSV export is included.

## Note
The current execution environment does not contain the .NET SDK, so the project could not be compiled here. The ZIP contains the complete source tree and reference assignment PDF for local build/test with .NET 8.

## Source Formatting
All source files are formatted with readable line breaks and indentation for easier study and editing.
