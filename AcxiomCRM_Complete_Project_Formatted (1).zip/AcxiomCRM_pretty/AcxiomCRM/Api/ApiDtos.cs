namespace AcxiomCRM.Api;
public record CustomerDto(int CustomerId, string CustomerCode, string CustomerName, string Email, string Phone, string? CompanyName, string Status);
public record CreateCustomerDto(string CustomerName, string Email, string Phone, string? CompanyName, string? Address, string? City, string? State, string Status);
public record LeadDto(int LeadId, string LeadCode, string LeadName, string Email, string Phone, string? CompanyName, string Source, string Status, string Priority, decimal ExpectedValue, string AssignedTo);
public record CreateLeadDto(string LeadName, string Email, string Phone, string? CompanyName, string Source, string Status, string Priority, decimal ExpectedValue, string? AssignedTo);
public record OpportunityDto(int OpportunityId, string OpportunityName, int CustomerId, decimal Amount, string Stage, int Probability, DateTime ExpectedCloseDate, string Status, string AssignedTo, decimal WeightedPipeline);
public record CreateOpportunityDto(string OpportunityName, int CustomerId, decimal Amount, string Stage, int Probability, DateTime ExpectedCloseDate, string Status, string? Notes, string? AssignedTo);
