using AcxiomCRM.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Data;
public static class DbInitializer {
    static readonly string[] Roles =["Admin", "Manager", "SalesExecutive"];
    public static async Task SeedAsync(IServiceProvider s) {
        var rm = s.GetRequiredService<RoleManager<IdentityRole>> ();
        var um = s.GetRequiredService<UserManager<ApplicationUser>> ();
        var db = s.GetRequiredService<AppDbContext>();
        foreach (var r in Roles) if (!await rm.RoleExistsAsync(r)) await rm.CreateAsync(new IdentityRole(r));
        var seeds = new[] {
            ("admin@acxiomcrm.local", "System Admin", "Admin", "Admin@12345"), ("manager@acxiomcrm.local", "Sales Manager", "Manager", "Manager@12345"), ("sales@acxiomcrm.local", "Sales Executive", "SalesExecutive", "Sales@12345")
        };
        var ids = new Dictionary<string, string>();
        foreach (var x in seeds) {
            var u = await um.FindByEmailAsync(x.Item1);
            if (u is null) {
                u = new ApplicationUser {
                    UserName = x.Item1, Email = x.Item1, EmailConfirmed = true, DisplayName = x.Item2, IsActive = true
                };
                var r = await um.CreateAsync(u, x.Item4);
                if (!r.Succeeded) throw new Exception(string.Join(";", r.Errors.Select(e => e.Description)));
            }
            if (!await um.IsInRoleAsync(u, x.Item3)) await um.AddToRoleAsync(u, x.Item3);
            ids[x.Item3] = u.Id;
        }
        if (!await db.Customers.AnyAsync()) {
            db.Customers.AddRange(new Customer {
                CustomerCode = "CUS-1001", CustomerName = "Ananya Rao", Email = "ananya@example.com", Phone = "9876543210", CompanyName = "Rao Technologies", City = "Hyderabad", State = "Telangana", CreatedBy = ids["SalesExecutive"]
            }, new Customer {
                CustomerCode = "CUS-1002", CustomerName = "Rahul Mehta", Email = "rahul@example.com", Phone = "9876543211", CompanyName = "Mehta Retail", City = "Hyderabad", State = "Telangana", Status = "Prospect", CreatedBy = ids["Manager"]
            });
            await db.SaveChangesAsync();
        }
        if (!await db.Leads.AnyAsync()) {
            db.Leads.AddRange(new Lead {
                LeadCode = "LED-1001", LeadName = "Priya Sharma", Email = "priya@example.com", Phone = "9876543220", CompanyName = "Sharma Foods", Source = "Website", Status = "Qualified", Priority = "High", ExpectedValue = 250000, AssignedTo = ids["SalesExecutive"]
            }, new Lead {
                LeadCode = "LED-1002", LeadName = "Kiran Kumar", Email = "kiran@example.com", Phone = "9876543221", CompanyName = "Kiran Logistics", Source = "Referral", Status = "Contacted", Priority = "Medium", ExpectedValue = 150000, AssignedTo = ids["SalesExecutive"]
            });
            await db.SaveChangesAsync();
        }
        if (!await db.Opportunities.AnyAsync()) {
            var c = await db.Customers.OrderBy(x => x.CustomerId).FirstAsync();
            db.Opportunities.AddRange(new Opportunity {
                OpportunityName = "Rao CRM Rollout", CustomerId = c.CustomerId, Amount = 500000, Stage = "Proposal", Probability = 60, ExpectedCloseDate = DateTime.Today.AddDays(30), AssignedTo = ids["SalesExecutive"]
            }, new Opportunity {
                OpportunityName = "Mehta Analytics Suite", CustomerId = c.CustomerId, Amount = 350000, Stage = "Negotiation", Probability = 75, ExpectedCloseDate = DateTime.Today.AddDays(45), AssignedTo = ids["Manager"]
            });
            await db.SaveChangesAsync();
        }
        if (!await db.FollowUps.AnyAsync()) {
            var c = await db.Customers.OrderBy(x => x.CustomerId).FirstAsync();
            db.FollowUps.Add(new FollowUp {
                CustomerId = c.CustomerId, FollowUpDate = DateTime.Today.AddDays(2), FollowUpType = "Call", Remarks = "Discuss proposal timeline", AssignedTo = ids["SalesExecutive"]
            });
            await db.SaveChangesAsync();
        }
    }
}
