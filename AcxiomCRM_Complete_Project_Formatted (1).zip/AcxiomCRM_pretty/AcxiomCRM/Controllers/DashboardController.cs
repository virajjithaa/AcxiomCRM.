using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class DashboardController: Controller {
    readonly IDashboardService s;
    public DashboardController(IDashboardService s) => this.s = s;
    public async Task<IActionResult> Index() {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier)!;
        return View(await s.GetAsync(id, User.IsInRole("Admin") || User.IsInRole("Manager")));
    }
}
