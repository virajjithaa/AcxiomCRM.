using AcxiomCRM.Data;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class ReportsController: Controller {
    readonly AppDbContext db;
    readonly ICsvExportService csv;
    public ReportsController(AppDbContext d, ICsvExportService c) {
        db = d;
        csv = c;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    public IActionResult Index() => View();
    public async Task<IActionResult> Customers() => View(await(Full? db.Customers: db.Customers.Where(x => x.CreatedBy == UID)).AsNoTracking().ToListAsync());
    public async Task<IActionResult> Leads() => View(await(Full? db.Leads: db.Leads.Where(x => x.AssignedTo == UID)).AsNoTracking().ToListAsync());
    public async Task<IActionResult> FollowUps() => View(await(Full? db.FollowUps: db.FollowUps.Where(x => x.AssignedTo == UID)).AsNoTracking().ToListAsync());
    public async Task<IActionResult> Opportunities() => View(await(Full? db.Opportunities: db.Opportunities.Where(x => x.AssignedTo == UID)).AsNoTracking().ToListAsync());
    public async Task<IActionResult> Pipeline() {
        var q = Full? db.Opportunities: db.Opportunities.Where(x => x.AssignedTo == UID);
        return View(await q.GroupBy(x => x.Stage).Select(g => new PipelineRow(g.Key, g.Sum(x => x.Amount), g.Sum(x => x.Amount * x.Probability / 100m))).ToListAsync());
    }
    public async Task<IActionResult> Conversion() {
        var q = Full? db.Leads: db.Leads.Where(x => x.AssignedTo == UID);
        var total = await q.CountAsync();
        var conv = await q.CountAsync(x => x.Status == "Converted");
        return View(new ConversionVm(total, await q.CountAsync(x => x.Status == "Qualified"), conv, total == 0 ? 0: Math.Round(conv * 100.0 / total, 2)));
    }
    [Authorize(Roles = "Admin,Manager")]
    public async Task<IActionResult> UserActivity() => View(await db.AuditLogs.GroupBy(x => x.UserId).Select(g => new UserActivityRow(g.Key, g.Count())).ToListAsync());
    [Authorize(Roles = "Admin")]
    public IActionResult Audit() => RedirectToAction("Index", "Audit");
    public async Task<IActionResult> ExportCustomers() {
        var q = Full? db.Customers: db.Customers.Where(x => x.CreatedBy == UID);
        var d = await q.Select(x => new {
            x.CustomerCode, x.CustomerName, x.Email, x.Phone, x.CompanyName, x.Status, x.CreatedDate
        }).ToListAsync();
        return File(csv.Create(d), "text/csv", "customers.csv");
    }
    public async Task<IActionResult> ExportLeads() {
        var q = Full? db.Leads: db.Leads.Where(x => x.AssignedTo == UID);
        var d = await q.Select(x => new {
            x.LeadCode, x.LeadName, x.Email, x.Phone, x.Source, x.Status, x.Priority, x.ExpectedValue
        }).ToListAsync();
        return File(csv.Create(d), "text/csv", "leads.csv");
    }
    public record PipelineRow(string Stage, decimal Amount, decimal Weighted);
    public record ConversionVm(int Total, int Qualified, int Converted, double ConversionPercent);
    public record UserActivityRow(string? UserId, int Actions);
}
