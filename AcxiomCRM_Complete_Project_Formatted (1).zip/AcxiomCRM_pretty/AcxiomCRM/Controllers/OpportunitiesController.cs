using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class OpportunitiesController: Controller {
    readonly AppDbContext db;
    readonly IAuditService audit;
    static readonly string[] S =["Qualification", "Proposal", "Negotiation", "Won", "Lost"];
    public OpportunitiesController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    IQueryable<Opportunity> Scope() => Full? db.Opportunities: db.Opportunities.Where(x => x.AssignedTo == UID);
    public async Task<IActionResult> Index(string? search, string? stage, int page = 1) {
        var q = Scope().AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.OpportunityName.Contains(search));
        if (!string.IsNullOrWhiteSpace(stage)) q = q.Where(x => x.Stage == stage);
        ViewBag.Page = page;
        ViewBag.Pages =(int) Math.Ceiling(await q.CountAsync() / 10d);
        ViewBag.Search = search;
        ViewBag.Stage = stage;
        ViewBag.Stages = S;
        ViewBag.Customers = await db.Customers.AsNoTracking().ToListAsync();
        return View(await q.OrderByDescending(x => x.OpportunityId).Skip((page - 1) * 10).Take(10).ToListAsync());
    }
    public async Task<IActionResult> Details(int id) {
        var x = await Scope().FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (x is null) return NotFound();
        ViewBag.Customer = await db.Customers.FindAsync(x.CustomerId);
        return View(x);
    }
    public async Task<IActionResult> Create() {
        ViewBag.Customers = await db.Customers.AsNoTracking().OrderBy(x => x.CustomerName).ToListAsync();
        ViewBag.Stages = S;
        return View(new Opportunity());
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Opportunity m) {
        ViewBag.Customers = await db.Customers.AsNoTracking().ToListAsync();
        ViewBag.Stages = S;
        if (!S.Contains(m.Stage)) ModelState.AddModelError(nameof(m.Stage), "Invalid stage.");
        if (!ModelState.IsValid) return View(m);
        m.AssignedTo = UID;
        m.CreatedDate = DateTime.UtcNow;
        db.Opportunities.Add(m);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Opportunity", m.OpportunityId.ToString(), null, AuditService.Snapshot(m));
        return RedirectToAction(nameof(Index));
    }
    [HttpGet]
    public async Task<IActionResult> Edit(int id) {
        var x = await Scope().FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (x is null) return NotFound();
        ViewBag.Customers = await db.Customers.ToListAsync();
        ViewBag.Stages = S;
        return View(x);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Opportunity m) {
        var x = await Scope().FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (x is null) return NotFound();
        if (!ModelState.IsValid) return View(m);
        if (m.Status == "Open" && m.ExpectedCloseDate.Date <DateTime.Today) ModelState.AddModelError(nameof(m.ExpectedCloseDate), "Expected Close Date cannot be in the past.");
        if (!ModelState.IsValid) {
            ViewBag.Customers = await db.Customers.ToListAsync();
            ViewBag.Stages = S;
            return View(m);
        }
        var old = AuditService.Snapshot(x);
        x.OpportunityName = m.OpportunityName;
        x.CustomerId = m.CustomerId;
        x.Amount = m.Amount;
        x.Stage = m.Stage;
        x.Probability = m.Probability;
        x.ExpectedCloseDate = m.ExpectedCloseDate;
        x.Status = m.Status;
        x.Notes = m.Notes;
        await db.SaveChangesAsync();
        await audit.LogAsync("Update", "Opportunity", id.ToString(), old, AuditService.Snapshot(x));
        return RedirectToAction(nameof(Details), new {
            id
        });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id) {
        var x = await Scope().FirstOrDefaultAsync(o => o.OpportunityId == id);
        if (x is null) return NotFound();
        var old = AuditService.Snapshot(x);
        x.Status = "Lost";
        x.Stage = "Lost";
        await db.SaveChangesAsync();
        await audit.LogAsync("Delete", "Opportunity", id.ToString(), old, AuditService.Snapshot(x), "Marked Lost");
        return RedirectToAction(nameof(Index));
    }
}
