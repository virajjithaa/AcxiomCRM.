using AcxiomCRM.Api;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers.Api;
[ApiController, Route("api/customers"), Authorize]
public class CustomersApiController: ControllerBase {
    readonly AppDbContext db;
    readonly IAuditService audit;
    public CustomersApiController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    [HttpGet]
    public async Task<IActionResult> Get(string? search) {
        var q = Full? db.Customers: db.Customers.Where(x => x.CreatedBy == UID);
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.CustomerName.Contains(search) || x.Email.Contains(search) || x.Phone.Contains(search));
        return Ok(await q.Select(x => new CustomerDto(x.CustomerId, x.CustomerCode, x.CustomerName, x.Email, x.Phone, x.CompanyName, x.Status)).ToListAsync());
    }
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id) {
        var x = await(Full? db.Customers: db.Customers.Where(c => c.CreatedBy == UID)).FirstOrDefaultAsync(c => c.CustomerId == id);
        return x is null ? NotFound() : Ok(new CustomerDto(x.CustomerId, x.CustomerCode, x.CustomerName, x.Email, x.Phone, x.CompanyName, x.Status));
    }
    [HttpPost]
    public async Task<IActionResult> Create(CreateCustomerDto d) {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);
        if (await db.Customers.AnyAsync(x => x.Email == d.Email || x.Phone == d.Phone)) return Conflict(new {
            message = "Email and phone must be unique."
        });
        var x = new Customer {
            CustomerCode = $"CUS-{DateTime.UtcNow:yyyyMMddHHmmssfff}", CustomerName = d.CustomerName, Email = d.Email, Phone = d.Phone, CompanyName = d.CompanyName, Address = d.Address, City = d.City, State = d.State, Status = d.Status, CreatedBy = UID
        };
        db.Customers.Add(x);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Customer", x.CustomerId.ToString(), null, AuditService.Snapshot(x));
        return CreatedAtAction(nameof(GetById), new {
            id = x.CustomerId
        }, new CustomerDto(x.CustomerId, x.CustomerCode, x.CustomerName, x.Email, x.Phone, x.CompanyName, x.Status));
    }
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, CreateCustomerDto d) {
        var x = await(Full? db.Customers: db.Customers.Where(c => c.CreatedBy == UID)).FirstOrDefaultAsync(c => c.CustomerId == id);
        if (x is null) return NotFound();
        if (await db.Customers.AnyAsync(c => c.CustomerId != id && (c.Email == d.Email || c.Phone == d.Phone))) return Conflict(new {
            message = "Email and phone must be unique."
        });
        var old = AuditService.Snapshot(x);
        x.CustomerName = d.CustomerName;
        x.Email = d.Email;
        x.Phone = d.Phone;
        x.CompanyName = d.CompanyName;
        x.Address = d.Address;
        x.City = d.City;
        x.State = d.State;
        x.Status = d.Status;
        await db.SaveChangesAsync();
        await audit.LogAsync("Update", "Customer", id.ToString(), old, AuditService.Snapshot(x));
        return NoContent();
    }
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id) {
        var x = await(Full? db.Customers: db.Customers.Where(c => c.CreatedBy == UID)).FirstOrDefaultAsync(c => c.CustomerId == id);
        if (x is null) return NotFound();
        var old = AuditService.Snapshot(x);
        x.Status = "Inactive";
        await db.SaveChangesAsync();
        await audit.LogAsync("Delete", "Customer", id.ToString(), old, AuditService.Snapshot(x), "Deactivated");
        return NoContent();
    }
}
