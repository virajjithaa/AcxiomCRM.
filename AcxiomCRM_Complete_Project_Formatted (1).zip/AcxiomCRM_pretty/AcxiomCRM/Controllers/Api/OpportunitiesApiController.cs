using AcxiomCRM.Api;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers.Api;
[ApiController, Route("api/opportunities"), Authorize]
public class OpportunitiesApiController: ControllerBase {
    readonly AppDbContext db;
    readonly IAuditService audit;
    static readonly string[] S =["Qualification", "Proposal", "Negotiation", "Won", "Lost"];
    public OpportunitiesApiController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    [HttpGet]
    public async Task<IActionResult> Get(string? search) {
        var q = Full? db.Opportunities: db.Opportunities.Where(x => x.AssignedTo == UID);
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.OpportunityName.Contains(search));
        return Ok(await q.Select(x => new OpportunityDto(x.OpportunityId, x.OpportunityName, x.CustomerId, x.Amount, x.Stage, x.Probability, x.ExpectedCloseDate, x.Status, x.AssignedTo, x.Amount * x.Probability / 100m)).ToListAsync());
    }
    [HttpPost]
    public async Task<IActionResult> Create(CreateOpportunityDto d) {
        if (d.Amount <= 0) return BadRequest(new {
            message = "Opportunity Amount must be greater than 0."
        });
        if (d.Probability <0 || d.Probability> 100) return BadRequest(new {
            message = "Probability must be between 0 and 100."
        });
        if (d.Status == "Open" && d.ExpectedCloseDate.Date <DateTime.Today) return BadRequest(new {
            message = "Expected Close Date cannot be in the past."
        });
        if (!S.Contains(d.Stage)) return BadRequest(new {
            message = "Invalid stage."
        });
        if (!await db.Customers.AnyAsync(c => c.CustomerId == d.CustomerId)) return BadRequest(new {
            message = "Customer not found."
        });
        var x = new Opportunity {
            OpportunityName = d.OpportunityName, CustomerId = d.CustomerId, Amount = d.Amount, Stage = d.Stage, Probability = d.Probability, ExpectedCloseDate = d.ExpectedCloseDate, Status = d.Status, Notes = d.Notes, AssignedTo = UID
        };
        db.Opportunities.Add(x);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Opportunity", x.OpportunityId.ToString(), null, AuditService.Snapshot(x));
        return Ok(new OpportunityDto(x.OpportunityId, x.OpportunityName, x.CustomerId, x.Amount, x.Stage, x.Probability, x.ExpectedCloseDate, x.Status, x.AssignedTo, x.WeightedPipeline));
    }
}
