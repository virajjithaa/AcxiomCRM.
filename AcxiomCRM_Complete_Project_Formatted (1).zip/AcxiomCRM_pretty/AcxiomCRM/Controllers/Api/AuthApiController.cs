using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
namespace AcxiomCRM.Controllers.Api;
[ApiController, Route("api/auth")]
public class AuthApiController: ControllerBase {
    readonly UserManager<ApplicationUser> u;
    readonly SignInManager <ApplicationUser> s;
    readonly IAuditService a;
    public AuthApiController(UserManager<ApplicationUser> u, SignInManager <ApplicationUser> s, IAuditService a) {
        this.u = u;
        this.s = s;
        this.a = a;
    }
    [AllowAnonymous, HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest m) {
        if (string.IsNullOrWhiteSpace(m.Email) || string.IsNullOrWhiteSpace(m.Password)) return BadRequest(new {
            message = "Email and password are required."
        });
        var x = await u.FindByEmailAsync(m.Email);
        if (x is null ||!x.IsActive) return Unauthorized(new {
            message = "Invalid credentials."
        });
        var r = await s.PasswordSignInAsync(x.UserName!, m.Password, m.RememberMe, true);
        await a.LogAsync(r.Succeeded?"Login": "Failed Login", "User", x.Id, null, null, r.Succeeded?"Success": (r.IsLockedOut?"LockedOut": "Rejected"));
        return r.Succeeded? Ok(new {
            message = "Authenticated", userId = x.Id, displayName = x.DisplayName
        }) : Unauthorized(new {
            message = r.IsLockedOut?"Account locked.": "Invalid credentials."
        });
    }
    [Authorize, HttpPost("logout")]
    public async Task<IActionResult> Logout() {
        var id = u.GetUserId(User);
        await s.SignOutAsync();
        await a.LogAsync("Logout", "User", id, null, null);
        return Ok(new {
            message = "Logged out"
        });
    }
}
public record LoginRequest(string Email, string Password, bool RememberMe = false);
