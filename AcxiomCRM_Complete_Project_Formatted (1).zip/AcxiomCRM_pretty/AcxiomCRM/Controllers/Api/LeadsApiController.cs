using AcxiomCRM.Api;
using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers.Api;
[ApiController, Route("api/leads"), Authorize]
public class LeadsApiController: ControllerBase {
    readonly AppDbContext db;
    readonly IAuditService audit;
    static readonly string[] S =["New", "Contacted", "Qualified", "Unqualified", "Converted", "Lost"];
    public LeadsApiController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    [HttpGet]
    public async Task<IActionResult> Get(string? search) {
        var q = Full? db.Leads: db.Leads.Where(x => x.AssignedTo == UID);
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.LeadName.Contains(search) || x.Email.Contains(search));
        return Ok(await q.Select(x => new LeadDto(x.LeadId, x.LeadCode, x.LeadName, x.Email, x.Phone, x.CompanyName, x.Source, x.Status, x.Priority, x.ExpectedValue, x.AssignedTo)).ToListAsync());
    }
    [HttpPost]
    public async Task<IActionResult> Create(CreateLeadDto d) {
        if (!S.Contains(d.Status)) return BadRequest(new {
            message = "Invalid lead status."
        });
        if (d.ExpectedValue <0) return BadRequest(new {
            message = "Expected value must not be negative."
        });
        var x = new Lead {
            LeadCode = $"LED-{DateTime.UtcNow:yyyyMMddHHmmssfff}", LeadName = d.LeadName, Email = d.Email, Phone = d.Phone, CompanyName = d.CompanyName, Source = d.Source, Status = d.Status, Priority = d.Priority, ExpectedValue = d.ExpectedValue, AssignedTo = UID
        };
        db.Leads.Add(x);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Lead", x.LeadId.ToString(), null, AuditService.Snapshot(x));
        return Ok(new LeadDto(x.LeadId, x.LeadCode, x.LeadName, x.Email, x.Phone, x.CompanyName, x.Source, x.Status, x.Priority, x.ExpectedValue, x.AssignedTo));
    }
}
