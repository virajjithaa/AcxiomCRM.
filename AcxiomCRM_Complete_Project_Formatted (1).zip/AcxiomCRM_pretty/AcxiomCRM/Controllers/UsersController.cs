using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize(Roles = "Admin")]
public class UsersController: Controller {
    readonly UserManager<ApplicationUser> u;
    readonly RoleManager<IdentityRole> r;
    readonly IAuditService a;
    public UsersController(UserManager<ApplicationUser> u, RoleManager<IdentityRole> r, IAuditService a) {
        this.u = u;
        this.r = r;
        this.a = a;
    }
    public async Task<IActionResult> Index(string? search) {
        var q = u.Users.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.DisplayName.Contains(search) || x.Email!.Contains(search));
        return View(await q.OrderBy(x => x.DisplayName).ToListAsync());
    }
    public async Task<IActionResult> Edit(string id) {
        var x = await u.FindByIdAsync(id);
        if (x is null) return NotFound();
        return View(new UserEditViewModel {
            Id = x.Id, DisplayName = x.DisplayName, Email = x.Email!, Role =(await u.GetRolesAsync(x)).FirstOrDefault() ? ? "SalesExecutive", IsActive = x.IsActive
        });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(UserEditViewModel m) {
        var x = await u.FindByIdAsync(m.Id);
        if (x is null) return NotFound();
        if (!ModelState.IsValid) return View(m);
        x.DisplayName = m.DisplayName;
        x.Email = m.Email;
        x.UserName = m.Email;
        x.IsActive = m.IsActive;
        var z = await u.UpdateAsync(x);
        if (!z.Succeeded) {
            foreach (var e in z.Errors) ModelState.AddModelError("", e.Description);
            return View(m);
        }
        var old = string.Join(',', await u.GetRolesAsync(x));
        await u.RemoveFromRolesAsync(x, await u.GetRolesAsync(x));
        await u.AddToRoleAsync(x, m.Role);
        if (!string.IsNullOrWhiteSpace(m.NewPassword)) {
            var token = await u.GeneratePasswordResetTokenAsync(x);
            await u.ResetPasswordAsync(x, token, m.NewPassword);
        }
        await a.LogAsync("Role Change", "User", x.Id, old, m.Role);
        return RedirectToAction(nameof(Index));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ToggleActive(string id) {
        var x = await u.FindByIdAsync(id);
        if (x is null) return NotFound();
        x.IsActive =!x.IsActive;
        await u.UpdateAsync(x);
        await a.LogAsync("Update", "User", id, null, x.IsActive.ToString());
        return RedirectToAction(nameof(Index));
    }
}
