using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class FollowUpsController: Controller {
    readonly AppDbContext db;
    readonly IAuditService audit;
    public FollowUpsController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    IQueryable<FollowUp> Scope() => Full? db.FollowUps: db.FollowUps.Where(x => x.AssignedTo == UID);
    public async Task<IActionResult> Index(string? status, int page = 1) {
        var q = Scope().AsNoTracking();
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(x => x.Status == status);
        ViewBag.Page = page;
        ViewBag.Pages =(int) Math.Ceiling(await q.CountAsync() / 10d);
        ViewBag.Status = status;
        return View(await q.OrderBy(x => x.FollowUpDate).Skip((page - 1) * 10).Take(10).ToListAsync());
    }
    public async Task<IActionResult> Create() {
        ViewBag.Customers = await db.Customers.ToListAsync();
        ViewBag.Leads = await db.Leads.ToListAsync();
        return View(new FollowUp());
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(FollowUp m) {
        ViewBag.Customers = await db.Customers.ToListAsync();
        ViewBag.Leads = await db.Leads.ToListAsync();
        if (!ModelState.IsValid) return View(m);
        m.AssignedTo = UID;
        db.FollowUps.Add(m);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "FollowUp", m.FollowUpId.ToString(), null, AuditService.Snapshot(m));
        return RedirectToAction(nameof(Index));
    }
    [HttpGet]
    public async Task<IActionResult> Edit(int id) {
        var x = await Scope().FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (x is null) return NotFound();
        ViewBag.Customers = await db.Customers.ToListAsync();
        ViewBag.Leads = await db.Leads.ToListAsync();
        return View(x);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, FollowUp m) {
        var x = await Scope().FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (x is null) return NotFound();
        if (!ModelState.IsValid) return View(m);
        var old = AuditService.Snapshot(x);
        x.CustomerId = m.CustomerId;
        x.LeadId = m.LeadId;
        x.FollowUpDate = m.FollowUpDate;
        x.FollowUpType = m.FollowUpType;
        x.Remarks = m.Remarks;
        x.Status = m.Status;
        await db.SaveChangesAsync();
        await audit.LogAsync("Update", "FollowUp", id.ToString(), old, AuditService.Snapshot(x));
        return RedirectToAction(nameof(Index));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Complete(int id) {
        var x = await Scope().FirstOrDefaultAsync(f => f.FollowUpId == id);
        if (x is null) return NotFound();
        var old = AuditService.Snapshot(x);
        x.Status = "Completed";
        await db.SaveChangesAsync();
        await audit.LogAsync("Complete", "FollowUp", id.ToString(), old, AuditService.Snapshot(x));
        return RedirectToAction(nameof(Index));
    }
}
