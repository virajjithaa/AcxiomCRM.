using AcxiomCRM.Models;
using AcxiomCRM.Services;
using AcxiomCRM.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
namespace AcxiomCRM.Controllers;
public class AccountController: Controller {
    readonly UserManager<ApplicationUser> u;
    readonly SignInManager <ApplicationUser> s;
    readonly IAuditService a;
    public AccountController(UserManager<ApplicationUser> u, SignInManager <ApplicationUser> s, IAuditService a) {
        this.u = u;
        this.s = s;
        this.a = a;
    }
    [AllowAnonymous]
    public IActionResult Login(string? returnUrl = null) => View(new LoginViewModel {
        ReturnUrl = returnUrl
    });
    [HttpPost, AllowAnonymous, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel m) {
        if (!ModelState.IsValid) return View(m);
        var user = await u.FindByEmailAsync(m.Email);
        if (user is null ||!user.IsActive) {
            await a.LogAsync("Failed Login", "User", user?.Id, null, null, "Rejected");
            ModelState.AddModelError("", "Invalid credentials or inactive account.");
            return View(m);
        }
        var r = await s.PasswordSignInAsync(user.UserName!, m.Password, m.RememberMe, true);
        await a.LogAsync(r.Succeeded?"Login": "Failed Login", "User", user.Id, null, null, r.IsLockedOut?"LockedOut": (r.Succeeded?"Success": "Rejected"));
        if (r.Succeeded) return LocalRedirect(m.ReturnUrl? ? Url.Action("Index", "Dashboard")!);
        ModelState.AddModelError("", r.IsLockedOut?"Account locked.": "Invalid credentials.");
        return View(m);
    }
    [AllowAnonymous]
    public IActionResult Register() => View(new RegisterViewModel());
    [HttpPost, AllowAnonymous, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel m) {
        if (!ModelState.IsValid) return View(m);
        var x = new ApplicationUser {
            UserName = m.Email, Email = m.Email, EmailConfirmed = true, DisplayName = m.DisplayName
        };
        var r = await u.CreateAsync(x, m.Password);
        if (!r.Succeeded) {
            foreach (var e in r.Errors) ModelState.AddModelError("", e.Description);
            return View(m);
        }
        await u.AddToRoleAsync(x, "SalesExecutive");
        await s.SignInAsync(x, false);
        await a.LogAsync("Register", "User", x.Id, null, "SalesExecutive");
        return RedirectToAction("Index", "Dashboard");
    }
    [HttpPost, Authorize, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout() {
        var id = u.GetUserId(User);
        await s.SignOutAsync();
        await a.LogAsync("Logout", "User", id, null, null);
        return RedirectToAction(nameof(Login));
    }
    public IActionResult AccessDenied() => View();
}
