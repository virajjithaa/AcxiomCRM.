using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class CustomersController: Controller {
    readonly AppDbContext db;
    readonly IAuditService audit;
    public CustomersController(AppDbContext db, IAuditService audit) {
        this.db = db;
        this.audit = audit;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    IQueryable<Customer> Scope() => Full? db.Customers: db.Customers.Where(x => x.CreatedBy == UID);
    public async Task<IActionResult> Index(string? search, string? status, int page = 1) {
        var q = Scope().AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.CustomerName.Contains(search) || x.Email.Contains(search) || x.Phone.Contains(search) || x.CompanyName!.Contains(search));
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(x => x.Status == status);
        ViewBag.Page = page;
        var n = await q.CountAsync();
        ViewBag.Pages =(int) Math.Ceiling(n / 10d);
        ViewBag.Search = search;
        ViewBag.Status = status;
        return View(await q.OrderByDescending(x => x.CustomerId).Skip((page - 1) * 10).Take(10).ToListAsync());
    }
    public async Task<IActionResult> Details(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.CustomerId == id);
        if (x is null) return NotFound();
        ViewBag.Opportunities = await db.Opportunities.Where(o => o.CustomerId == id).ToListAsync();
        ViewBag.FollowUps = await db.FollowUps.Where(f => f.CustomerId == id).ToListAsync();
        return View(x);
    }
    public IActionResult Create() => View(new Customer());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Customer m) {
        if (await db.Customers.AnyAsync(x => x.Email == m.Email || x.Phone == m.Phone)) ModelState.AddModelError("", "Duplicate customer: email and phone must be unique.");
        if (!ModelState.IsValid) return View(m);
        m.CustomerCode = $"CUS-{DateTime.UtcNow:yyyyMMddHHmmssfff}";
        m.CreatedBy = UID;
        m.CreatedDate = DateTime.UtcNow;
        db.Customers.Add(m);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Customer", m.CustomerId.ToString(), null, AuditService.Snapshot(m));
        return RedirectToAction(nameof(Index));
    }
    [HttpGet]
    public async Task<IActionResult> Edit(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.CustomerId == id);
        return x is null ? NotFound() : View(x);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Customer m) {
        var x = await Scope().FirstOrDefaultAsync(c => c.CustomerId == id);
        if (x is null) return NotFound();
        if (await db.Customers.AnyAsync(c => c.CustomerId != id && (c.Email == m.Email || c.Phone == m.Phone))) ModelState.AddModelError("", "Email and phone must remain unique.");
        if (!ModelState.IsValid) return View(m);
        var old = AuditService.Snapshot(x);
        x.CustomerName = m.CustomerName;
        x.Email = m.Email;
        x.Phone = m.Phone;
        x.CompanyName = m.CompanyName;
        x.Address = m.Address;
        x.City = m.City;
        x.State = m.State;
        x.Status = m.Status;
        await db.SaveChangesAsync();
        await audit.LogAsync("Update", "Customer", id.ToString(), old, AuditService.Snapshot(x));
        return RedirectToAction(nameof(Details), new {
            id
        });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.CustomerId == id);
        if (x is null) return NotFound();
        var old = AuditService.Snapshot(x);
        x.Status = "Inactive";
        await db.SaveChangesAsync();
        await audit.LogAsync("Delete", "Customer", id.ToString(), old, AuditService.Snapshot(x), "Deactivated");
        return RedirectToAction(nameof(Index));
    }
}
