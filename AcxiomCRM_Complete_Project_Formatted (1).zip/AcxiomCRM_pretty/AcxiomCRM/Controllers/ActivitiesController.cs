using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class ActivitiesController: Controller {
    readonly AppDbContext db;
    readonly IAuditService audit;
    public ActivitiesController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    IQueryable<Activity> Scope() => Full? db.Activities: db.Activities.Where(x => x.AssignedTo == UID);
    public async Task<IActionResult> Index(int page = 1) {
        var q = Scope().AsNoTracking();
        ViewBag.Page = page;
        ViewBag.Pages =(int) Math.Ceiling(await q.CountAsync() / 10d);
        return View(await q.OrderByDescending(x => x.ActivityDate).Skip((page - 1) * 10).Take(10).ToListAsync());
    }
    public async Task<IActionResult> Create() {
        ViewBag.Customers = await db.Customers.ToListAsync();
        ViewBag.Leads = await db.Leads.ToListAsync();
        return View(new Activity());
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Activity m) {
        if (!ModelState.IsValid) {
            ViewBag.Customers = await db.Customers.ToListAsync();
            ViewBag.Leads = await db.Leads.ToListAsync();
            return View(m);
        }
        m.AssignedTo = UID;
        db.Activities.Add(m);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Activity", m.ActivityId.ToString(), null, AuditService.Snapshot(m));
        return RedirectToAction(nameof(Index));
    }
    [HttpGet]
    public async Task<IActionResult> Edit(int id) {
        var x = await Scope().FirstOrDefaultAsync(a => a.ActivityId == id);
        return x is null ? NotFound() : View(x);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Activity m) {
        var x = await Scope().FirstOrDefaultAsync(a => a.ActivityId == id);
        if (x is null) return NotFound();
        if (!ModelState.IsValid) return View(m);
        var old = AuditService.Snapshot(x);
        x.ActivityType = m.ActivityType;
        x.Subject = m.Subject;
        x.Description = m.Description;
        x.ActivityDate = m.ActivityDate;
        x.CustomerId = m.CustomerId;
        x.LeadId = m.LeadId;
        x.Status = m.Status;
        await db.SaveChangesAsync();
        await audit.LogAsync("Update", "Activity", id.ToString(), old, AuditService.Snapshot(x));
        return RedirectToAction(nameof(Index));
    }
}
