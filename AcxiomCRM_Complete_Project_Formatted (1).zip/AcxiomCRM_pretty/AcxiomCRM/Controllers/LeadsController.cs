using AcxiomCRM.Data;
using AcxiomCRM.Models;
using AcxiomCRM.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
namespace AcxiomCRM.Controllers;
[Authorize]
public class LeadsController: Controller {
    readonly AppDbContext db;
    readonly IAuditService audit;
    static readonly string[] S =["New", "Contacted", "Qualified", "Unqualified", "Converted", "Lost"];
    public LeadsController(AppDbContext d, IAuditService a) {
        db = d;
        audit = a;
    }
    string UID => User.FindFirstValue(ClaimTypes.NameIdentifier)!;
    bool Full => User.IsInRole("Admin") || User.IsInRole("Manager");
    IQueryable<Lead> Scope() => Full? db.Leads: db.Leads.Where(x => x.AssignedTo == UID);
    public async Task<IActionResult> Index(string? search, string? status, int page = 1) {
        var q = Scope().AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.LeadName.Contains(search) || x.Email.Contains(search) || x.CompanyName!.Contains(search));
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(x => x.Status == status);
        ViewBag.Page = page;
        ViewBag.Pages =(int) Math.Ceiling(await q.CountAsync() / 10d);
        ViewBag.Search = search;
        ViewBag.Status = status;
        ViewBag.Statuses = S;
        return View(await q.OrderByDescending(x => x.LeadId).Skip((page - 1) * 10).Take(10).ToListAsync());
    }
    public async Task<IActionResult> Details(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.LeadId == id);
        return x is null ? NotFound() : View(x);
    }
    public IActionResult Create() => View(new Lead());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Lead m) {
        if (!S.Contains(m.Status)) ModelState.AddModelError(nameof(m.Status), "Invalid lead status.");
        if (!ModelState.IsValid) return View(m);
        m.LeadCode = $"LED-{DateTime.UtcNow:yyyyMMddHHmmssfff}";
        m.AssignedTo = UID;
        m.CreatedDate = DateTime.UtcNow;
        db.Leads.Add(m);
        await db.SaveChangesAsync();
        await audit.LogAsync("Create", "Lead", m.LeadId.ToString(), null, AuditService.Snapshot(m));
        return RedirectToAction(nameof(Index));
    }
    [HttpGet]
    public async Task<IActionResult> Edit(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.LeadId == id);
        if (x is null) return NotFound();
        ViewBag.Statuses = S;
        return View(x);
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Lead m) {
        var x = await Scope().FirstOrDefaultAsync(c => c.LeadId == id);
        if (x is null) return NotFound();
        if (!S.Contains(m.Status)) ModelState.AddModelError(nameof(m.Status), "Invalid lead status.");
        if (!ModelState.IsValid) {
            ViewBag.Statuses = S;
            return View(m);
        }
        var old = AuditService.Snapshot(x);
        x.LeadName = m.LeadName;
        x.Email = m.Email;
        x.Phone = m.Phone;
        x.CompanyName = m.CompanyName;
        x.Source = m.Source;
        x.Status = m.Status;
        x.Priority = m.Priority;
        x.ExpectedValue = m.ExpectedValue;
        await db.SaveChangesAsync();
        await audit.LogAsync("Update", "Lead", id.ToString(), old, AuditService.Snapshot(x));
        return RedirectToAction(nameof(Details), new {
            id
        });
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.LeadId == id);
        if (x is null) return NotFound();
        var old = AuditService.Snapshot(x);
        x.Status = "Lost";
        await db.SaveChangesAsync();
        await audit.LogAsync("Delete", "Lead", id.ToString(), old, AuditService.Snapshot(x), "Marked Lost");
        return RedirectToAction(nameof(Index));
    }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Convert(int id) {
        var x = await Scope().FirstOrDefaultAsync(c => c.LeadId == id);
        if (x is null) return NotFound();
        if (x.Status != "Qualified") return BadRequest("Only Qualified leads can be converted.");
        if (await db.Customers.AnyAsync(c => c.Email == x.Email || c.Phone == x.Phone)) {
            TempData["Error"] = "A customer with this email or phone already exists.";
            return RedirectToAction(nameof(Details), new {
                id
            });
        }
        var c = new Customer {
            CustomerCode = $"CUS-{DateTime.UtcNow:yyyyMMddHHmmssfff}", CustomerName = x.LeadName, Email = x.Email, Phone = x.Phone, CompanyName = x.CompanyName, Status = "Active", CreatedBy = x.AssignedTo
        };
        db.Customers.Add(c);
        x.Status = "Converted";
        await db.SaveChangesAsync();
        await audit.LogAsync("Convert", "Lead", id.ToString(), null, $"CustomerId={c.CustomerId}");
        return RedirectToAction("Details", "Customers", new {
            id = c.CustomerId
        });
    }
}
