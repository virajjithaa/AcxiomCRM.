using AcxiomCRM.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace AcxiomCRM.Controllers;
[Authorize(Roles = "Admin")]
public class AuditController: Controller {
    readonly AppDbContext db;
    public AuditController(AppDbContext db) => this.db = db;
    public async Task<IActionResult> Index(int page = 1) {
        var q = db.AuditLogs.AsNoTracking();
        ViewBag.Page = page;
        ViewBag.Pages =(int) Math.Ceiling(await q.CountAsync() / 20d);
        return View(await q.OrderByDescending(x => x.AuditLogId).Skip((page - 1) * 20).Take(20).ToListAsync());
    }
}
