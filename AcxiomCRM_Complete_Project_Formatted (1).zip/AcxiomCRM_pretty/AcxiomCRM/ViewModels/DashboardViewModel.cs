namespace AcxiomCRM.ViewModels;
public record ChartItem(string Label, double Value);
public class DashboardViewModel {
    public int TotalCustomers {
        get;
        set;
    }
    public int TotalLeads {
        get;
        set;
    }
    public int OpenLeads {
        get;
        set;
    }
    public int TotalOpportunities {
        get;
        set;
    }
    public int OpenOpportunities {
        get;
        set;
    }
    public int WonOpportunities {
        get;
        set;
    }
    public int LostOpportunities {
        get;
        set;
    }
    public int PendingFollowUps {
        get;
        set;
    }
    public int OverdueFollowUps {
        get;
        set;
    }
    public decimal TotalPipelineValue {
        get;
        set;
    }
    public List<ChartItem> LeadStatus {
        get;
        set;
    }
    =[];
    public List<ChartItem> StageStatus {
        get;
        set;
    }
    =[];
    public List<ChartItem> MonthlySales {
        get;
        set;
    }
    =[];
}
