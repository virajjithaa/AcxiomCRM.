using System.ComponentModel.DataAnnotations;
namespace AcxiomCRM.ViewModels;
public class LoginViewModel {
    [Required, EmailAddress]
    public string Email {
        get;
        set;
    }
    = "";
    [Required, DataType(DataType.Password)]
    public string Password {
        get;
        set;
    }
    = "";
    public bool RememberMe {
        get;
        set;
    }
    public string? ReturnUrl {
        get;
        set;
    }
}
public class RegisterViewModel {
    [Required]
    public string DisplayName {
        get;
        set;
    }
    = "";
    [Required, EmailAddress]
    public string Email {
        get;
        set;
    }
    = "";
    [Required, DataType(DataType.Password), MinLength(8)]
    public string Password {
        get;
        set;
    }
    = "";
    [Required, DataType(DataType.Password), Compare(nameof(Password))]
    public string ConfirmPassword {
        get;
        set;
    }
    = "";
}
public class UserEditViewModel {
    public string Id {
        get;
        set;
    }
    = "";
    [Required]
    public string DisplayName {
        get;
        set;
    }
    = "";
    [Required, EmailAddress]
    public string Email {
        get;
        set;
    }
    = "";
    [Required]
    public string Role {
        get;
        set;
    }
    = "SalesExecutive";
    public bool IsActive {
        get;
        set;
    }
    = true;
    [DataType(DataType.Password)]
    public string? NewPassword {
        get;
        set;
    }
}
