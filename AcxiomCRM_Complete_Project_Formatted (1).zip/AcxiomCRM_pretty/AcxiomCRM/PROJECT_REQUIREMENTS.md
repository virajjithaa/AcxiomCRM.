# Requirement Traceability

The supplied PDF requires: layered architecture; Admin, Manager and Sales Executive; Customers, Leads, Opportunities, Follow-Ups, Activities, Users/Roles, Audit Log, REST API and Reports; client/server/business validation; Identity password hashing/policy/lockout; server-side role authorization; anti-forgery; dashboard KPIs and Chart.js; search/filter/pagination; audit entries; DTO-based APIs; and role-scoped reporting.

Implemented in this source tree:
- `Models/` domain and Identity models.
- `Data/AppDbContext.cs` Identity + CRM EF model and uniqueness indexes.
- `Data/DbInitializer.cs` roles, users and demo records.
- `Services/AuditService.cs` append-style audit events.
- `Services/DashboardService.cs` authorized KPI/chart data.
- `Controllers/` MVC workflows with server-side authorization and validation.
- `Controllers/Api/` secured Customer/Lead/Opportunity + Identity auth endpoints.
- `Views/` Bootstrap UI, forms, validation messages and reports.
- `wwwroot/` common CSS/JS and Chart.js integration.
